<?php $__env->startSection('title'); ?>
    <title>Service Hunt Admin : Services</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Services
      <small>table</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Tables</a></li>
      <li class="active">All Services</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
              <h3 class="box-title">All available Services</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Date</th>
                  <th>Title</th>
                  <th>Owner</th>
                  <th>SubCategory</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><span class="label label-info"><?php echo e($service->created_at->format('M-d-Y')); ?></span></td>
                  <td><img src="/admin_inc/dist/img/user2-160x160.jpg" class="img-circle" width="40"/>
                    <?php echo e($service->title); ?>

                  </td>
                  <td><?php echo e($service->user->first_name); ?></td>
                  <td> <?php echo e($service->sub_category->name); ?></td>
                  <td>
                  <?php if($service->active==1): ?>
                  <a class="btn btn-primary btn-xs">Approved</a>
                  <?php else: ?>
                  <a class="btn btn-warning btn-xs">Delete</a>
                  <?php endif; ?>
                  </td>
                  <td>
                    <div class="timeline-footer">
                      <a class="btn btn-primary btn-xs">Edit</a>
                      <a class="btn btn-danger btn-xs">Delete</a>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Date</th>
                  <th>Title</th>
                  <th>Owner</th>
                  <th>SubCategory</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>