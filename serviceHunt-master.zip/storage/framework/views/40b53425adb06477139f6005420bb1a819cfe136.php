<div id="search-row-wrapper">
  <div class="container">
    <div class="search-inner">

      <div class="row search-bar">
        <div class="advanced-search">
          <form class="search-form" action="/search" method="get">
            <div class="col-md-3 col-sm-6 search-col">
              <div class="input-group-addon search-category-container">
                <label class="styled-select">
                  <select class="dropdown-product selectpicker" name="subcategory">
                    <option value="0">All Sub Categories</option>
                    <?php $__currentLoopData = App\SubCategory::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option class="subitem" value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </label>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 search-col">
              <div class="input-group-addon search-category-container">
                <label class="styled-select location-select">
                  <input class="form-control keyword" type="text" name="town" list="cities" placeholder="Enter your Location">
                </label>
              </div>
            </div>
            <div class="col-md-3 col-sm-6 search-col">
              <input class="form-control keyword" name="keyword" value="" placeholder="Enter Keyword" type="text">
              <i class="fa fa-search"></i>
            </div>
            <div class="col-md-3 col-sm-6 search-col">
              <button class="btn btn-common btn-search btn-block"><strong>Search</strong></button>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
</div>
