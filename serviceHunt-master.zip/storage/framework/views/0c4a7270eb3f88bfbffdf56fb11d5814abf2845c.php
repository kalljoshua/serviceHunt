<div class="col-sm-3 page-sidebar">
  <aside>
    <div class="inner-box">
      <div class="categories">
        <div class="widget-title">
          <i class="fa fa-align-justify"></i>
          <h4>All Categories</h4>
        </div>
        <div class="categories-list">
          <ul>
            <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->sub_category->count()>0): ?>
              <div class="category-header">
                <a data-toggle="collapse" href="#collapse<?php echo e($category->id); ?>">
                <i class="fa fa-tags"></i>
                <?php echo e($category->name); ?> <span class="category-counter">(<?php echo e($category->sub_category->count()); ?>)</span></a>
              </div>
              <div id="collapse<?php echo e($category->id); ?>" class="category-content">
                <?php $__currentLoopData = App\SubCategory::where('category_id', $category->id)->orderBy('created_at','DESC')->take(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($sub_category->services->count()>0): ?>
                <li>
                  <a href="/services/<?php echo e($sub_category->id); ?>/category"><?php echo e($sub_category->name); ?>

                    <span class="category-counter">(<?php echo e($sub_category->services->count()); ?>)</span></a>

                </li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>
    </div>
    <div class="inner-box">
      <div class="widget-title">
        <h4>Premium Ads</h4>
      </div>
      <div class="advimg">
        <ul class="featured-list">
          <li>
            <img alt="" src="/client_inc/assets/img/featured/img1.jpg">
            <div class="hover">
              <a href="category.html#"><span>$49</span></a>
            </div>
          </li>
          <li>
            <img alt="" src="/client_inc/assets//img/featured/img2.jpg">
            <div class="hover">
              <a href="category.html#"><span>$49</span></a>
            </div>
          </li>
          <li>
            <img alt="" src="/client_inc/assets//img/featured/img3.jpg">
            <div class="hover">
              <a href="category.html#"><span>$49</span></a>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="inner-box">
      <div class="widget-title">
        <h4>Advertisement</h4>
      </div>
      <img src="/client_inc/assets//img/img1.jpg" alt="">
    </div>
  </aside>
</div>
