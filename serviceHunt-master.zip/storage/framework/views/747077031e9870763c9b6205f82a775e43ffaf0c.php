<div class="col-sm-3 page-sideabr">
  <aside>
    <div class="inner-box">
      <div class="user-panel-sidebar">
        <div class="collapse-box">
          <h5 class="collapset-title no-border">My Classified <a aria-expanded="true" class="pull-right" data-toggle="collapse" href="account-home.html#myclassified"><i class="fa fa-angle-down"></i></a></h5>
          <div aria-expanded="true" id="myclassified" class="panel-collapse collapse in">
            <ul class="acc-list">
              <li class="active">
                <a href="<?php echo e(route('user.profile')); ?>"><i class="fa fa-home"></i> Personal Home</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="collapse-box">
          <h5 class="collapset-title">My Ads <a aria-expanded="true" class="pull-right" data-toggle="collapse" href="account-home.html#myads"><i class="fa fa-angle-down"></i></a></h5>
          <div aria-expanded="true" id="myads" class="panel-collapse collapse in">
            <ul class="acc-list">
              <li>
                <a href="<?php echo e(route('user.myads',['userId' => Auth::guard('user')->id()])); ?>">
                  <i class="fa fa-credit-card"></i> My Ads</a>
              </li>
              <li>
                <a href="<?php echo e(route('user.favourites',['userId' => Auth::guard('user')->id()])); ?>">
                  <i class="fa fa-heart-o"></i> Favourite Ads</a>
              </li>
              <li>
                <a href="<?php echo e(route('user.search',['userId' => Auth::guard('user')->id()])); ?>">
                  <i class="fa fa-star-o"></i> Saved Search </a>
              </li>
              <li>
                <a href="<?php echo e(route('user.archived',['userId' => Auth::guard('user')->id()])); ?>">
                  <i class="fa fa-folder-o"></i> Archived Ads</a>
              </li>
              <li>
                <a href="<?php echo e(route('user.pending',['userId' => Auth::guard('user')->id()])); ?>">
                  <i class="fa fa-hourglass-o"></i> Pending Approval </a>
              </li>
            </ul>
          </div>
        </div>
        <div class="collapse-box">
          <h5 class="collapset-title">Companies <a aria-expanded="true" class="pull-right" data-toggle="collapse" href="account-home.html#close"><i class="fa fa-angle-down"></i></a></h5>
          <div aria-expanded="true" id="close" class="panel-collapse collapse in">
            <ul class="acc-list">
             <?php
             $auth_user_id = Auth::guard('user')->id();
             $companies = App\Company::where('user_id',$auth_user_id)->get();?>
             <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <a href="#"><i class="fa fa-industry"></i> <?php echo e($company->name); ?></a>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e(route('company.create')); ?>"><i class="fa fa-plus"></i> New Company</a>
            </li>
            </ul>
          </div>
        </div>
        <div class="collapse-box">
          <h5 class="collapset-title">Terminate Account <a aria-expanded="true" class="pull-right" data-toggle="collapse" href="account-home.html#close"><i class="fa fa-angle-down"></i></a></h5>
          <div aria-expanded="true" id="close" class="panel-collapse collapse in">
            <ul class="acc-list">
              <li>
                <a href="account-close.html"><i class="fa fa-close"></i> Close Account</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="inner-box">
      <div class="widget-title">
        <h4>Advertisement</h4>
      </div>
      <img src="/client_inc/assets//img/img1.jpg" alt="">
    </div>
  </aside>
</div>
