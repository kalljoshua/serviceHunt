<?php $__env->startSection('title'); ?>
<title>Service Hunt : My Ads</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('user.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="content">
  <div class="container">
    <div class="row">
      <?php echo $__env->make("user.side_bar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-sm-9 page-content">
        <div class="inner-box">
          <h2 class="title-2"><i class="fa fa-credit-card"></i> My Ads</h2>
          <?php if(sizeof($services)>0): ?>
          <div class="table-responsive">
            <div class="adds-wrapper">
              <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="item-list">
                <div class="col-sm-2 no-padding photobox">
                  <div class="add-image">
                    <a href="category.html#"><img src="/client_inc/assets//img/item/img-1.jpg" alt=""></a>
                    <span class="photo-count"><i class="fa fa-camera"></i>2</span>
                  </div>
                </div>
                <div class="col-sm-7 add-desc-box">
                  <div class="add-details">
                    <h5 class="add-title"><a href="/services/<?php echo e($service->id); ?>/details"><?php echo e($service->title); ?></a></h5>
                    <div class="info">
                      <span class="date">
                        <i class="fa fa-clock"></i>
                        <?php echo date_format($service->created_at, 'G:ia Y-m-d');?>
                      </span> -
                      <span class="category"><?php echo e($service->sub_category->category->name); ?></span> -
                      <span class="item-location"><i class="fa fa-map-marker"></i><?php echo e($service->district); ?></span>
                    </div>
                    <div class="item_desc">
                      <a href="category.html#">
                        <?php echo e(str_limit($service->description, $limit = 70, $end = '...')); ?>

                      </a>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 text-right  price-box">
                  <a class="btn btn-warning btn-sm"><?php echo e($service->type->name); ?></a>
                  <a class="btn btn-danger btn-sm"><i class="fa fa-certificate"></i>
                    <span>Delete</span></a>
                    <a class="btn btn-common btn-sm"> <i class="fa fa-eye"></i> <span><?php echo e($service->views); ?></span> </a>
                    <a class="btn btn-info btn-sm">Edit</a>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            <?php else: ?>
            <div class="text-center" style="margin-top:50px">
            <h3>No Pending Services available under your account!</h3>
          </div>
            <?php endif; ?>
          </div>
        </div>
        <div class="pagination-bar">
          <ul class="pagination">
            <?php echo $services->render(); ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('...layouts.userLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>